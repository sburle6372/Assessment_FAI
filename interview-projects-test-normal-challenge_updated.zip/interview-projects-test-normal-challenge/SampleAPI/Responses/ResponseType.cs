﻿
using SampleAPI.Entities;
using System.Collections.Generic;

namespace SampleAPI.Responses
{

    public class ResponseResult
    {
        public bool Success { get; set; }
        public string Message { get; set; }
    }

    public class OrdersResult : ResponseResult
    {
        public IEnumerable<Order> Orders { get; set; }
    }
}
