﻿using System.ComponentModel.DataAnnotations;

namespace SampleAPI.Entities
{
    public class Order
    {
        [Required(ErrorMessage = "ID is required.")]
        [Range(1, int.MaxValue, ErrorMessage = "ID must be a positive number.")]
        public int Id { get; set; }

        [Required(ErrorMessage = "Entry date is required.")]
        public DateTime EntryDate { get; set; }

        [Required(ErrorMessage = "Name is required.")]
        [StringLength(100, ErrorMessage = "CustomerName can't be longer than 100 characters.")]
        public string CustomerName { get; set; }

        [StringLength(100, ErrorMessage = "Description can't be longer than 100 characters.")]
        public string OrderDescription { get; set; }

        [Required]
        public bool IsInvoiced { get; set; } = true;

        [Required]
        public bool IsDeleted { get; set; } = false;
    }
}
