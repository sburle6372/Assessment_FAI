﻿using Microsoft.AspNetCore.Mvc;
using SampleAPI.Entities;
using SampleAPI.Repositories;
using SampleAPI.Requests;

namespace SampleAPI.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class OrdersController : ControllerBase
    {
        private readonly IOrderRepository _orderRepository;

        public OrdersController(IOrderRepository orderRepository)
        {
            _orderRepository = orderRepository;
        }

        [HttpGet("recent")]
        [ProducesResponseType(typeof(IEnumerable<Order>), 200)]
        [ProducesResponseType(400)]
        [ProducesResponseType(500)]
        public ActionResult<IEnumerable<Order>> GetRecentOrders()
        {
            var recentOrders = _orderRepository.GetRecentOrder();
            if (recentOrders.Success)
            {
                return Ok(recentOrders.Orders);
            }
            return StatusCode(500, recentOrders.Message);
        }

        [HttpPost]
        [ProducesResponseType(typeof(Order), 201)]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(400)]
        [ProducesResponseType(500)]
        public ActionResult<Order> AddNewOrder([FromBody] Order orderRequest)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            var order = new Order
            {
                Id = orderRequest.Id,
                EntryDate = orderRequest.EntryDate,
                CustomerName = orderRequest.CustomerName,
                OrderDescription = orderRequest.OrderDescription,
                IsInvoiced = orderRequest.IsInvoiced,
                IsDeleted = orderRequest.IsDeleted
            };

            _orderRepository.AddNewOrder(order);

            return CreatedAtAction(nameof(AddNewOrder), new { id = order.Id }, order);
        }

        [HttpGet("excludingHolidaysWeekends")]
        [ProducesResponseType(typeof(IEnumerable<Order>), 200)]
        [ProducesResponseType(400)]
        [ProducesResponseType(500)]
        public ActionResult<IEnumerable<Order>> GetOrdersExcludingHolidaysAndWeekends([FromQuery] int days)
        {
            var result = _orderRepository.GetOrdersExcludingHolidaysAndWeekends(days);
            if (result.Success)
            {
                return Ok(result.Orders);
            }
            return StatusCode(500, result.Message);
        }
    }
}
