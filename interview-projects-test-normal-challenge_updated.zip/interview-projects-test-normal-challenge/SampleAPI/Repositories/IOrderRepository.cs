﻿using SampleAPI.Entities;
using SampleAPI.Requests;
using SampleAPI.Responses;

namespace SampleAPI.Repositories
{
    public interface IOrderRepository
    {
        // TODO: Create repository methods.
        public OrdersResult GetRecentOrder();

        public ResponseResult AddNewOrder(Order order);

        public OrdersResult GetOrdersExcludingHolidaysAndWeekends(int days);
    }
}
