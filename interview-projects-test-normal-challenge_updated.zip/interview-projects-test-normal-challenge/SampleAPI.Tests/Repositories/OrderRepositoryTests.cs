using FluentAssertions;
using FluentAssertions.Extensions;
using SampleAPI.Entities;
using SampleAPI.Repositories;
using SampleAPI.Requests;
using Xunit;

namespace SampleAPI.Tests.Repositories
{
    public class OrderRepositoryTests
    {
        private readonly OrderRepository _repository;

        public OrderRepositoryTests()
        {
            _repository = new OrderRepository();
        }

        [Fact]
        public void GetOrders()
        {
            // Arrange
            var order1 = new Order { Id = 1, EntryDate = DateTime.Now.AddDays(-1), CustomerName = "John Doe", OrderDescription = "three items added to cart", IsDeleted = false, IsInvoiced = true };
            var order2 = new Order { Id = 2, EntryDate = DateTime.Now, CustomerName = "Jane Doe", OrderDescription = "four items added to cart", IsDeleted = true, IsInvoiced = true };
            _repository.AddNewOrder(order1);
            _repository.AddNewOrder(order2);

            // Act
            var result = _repository.GetRecentOrder();

            // Assert
            Assert.True(result.Success);
            Assert.Equal(2, result.Orders.Count());
        }

        [Fact]
        public void GetRecentOrders()
        {
            // Arrange
            var order1 = new Order { Id = 1, EntryDate = DateTime.Now.AddDays(-1), CustomerName = "John Doe", OrderDescription = "three items added to cart", IsDeleted = false, IsInvoiced=true };
            var order2 = new Order { Id = 2, EntryDate = DateTime.Now, CustomerName = "Jane Doe", OrderDescription = "four items added to cart", IsDeleted = true, IsInvoiced = true };
            _repository.AddNewOrder(order1);
            _repository.AddNewOrder(order2);

            // Act
            var result = _repository.GetRecentOrder();

            // Assert
            Assert.True(result.Success);
            Assert.Single(result.Orders);
        }

        public void AddNewOrder_AddsOrderSuccessfully()
        {
            // Arrange
            var order = new Order { Id = 3, EntryDate = DateTime.Now, CustomerName = "Alice Smith", OrderDescription = "six items added to cart", IsDeleted = false, IsInvoiced = true };

            // Act
            var result = _repository.AddNewOrder(order);

            // Assert
            Assert.True(result.Success);
            Assert.Equal("Order added successfully.", result.Message);
        }
    }
}