﻿using Microsoft.EntityFrameworkCore;
using SampleAPI.Entities;
using SampleAPI.Requests;
using SampleAPI.Responses;

namespace SampleAPI.Repositories
{
    public class OrderRepository : IOrderRepository
    {
        private readonly List<Order> _orders = new List<Order>();
        public OrdersResult GetRecentOrder()
        {
            var result = new OrdersResult();

            try
            {
                result.Orders = _orders.Where(order => order.EntryDate >= DateTime.UtcNow.AddDays(-1) && !order.IsDeleted).ToList();
                result.Success = true;
                result.Message = "Orders retrieved successfully.";
            }
            catch (Exception ex)
            {
                result.Success = false;
                result.Message = $"An error occurred: {ex.Message}";
            }

            return result;
        }
        public ResponseResult AddNewOrder(Order order)
        {
            var result = new ResponseResult();

            try
            {
                if (order == null)
                {
                    result.Success = false;
                    result.Message = "Order cannot be null.";
                    return result;
                }

                _orders.Add(order);
                result.Success = true;
                result.Message = "Order added successfully.";
            }
            catch (Exception ex)
            {
                result.Success = false;
                result.Message = $"An error occurred: {ex.Message}";
            }

            return result;
        }

        public OrdersResult GetOrdersExcludingHolidaysAndWeekends(int days)
        {
            var result = new OrdersResult();
            var cutoffDate = DateTime.Now.AddDays(-days);

            try
            {
                result.Orders = _orders
                    .Where(order => IsWeekday(order.EntryDate) && !IsHoliday(order.EntryDate) && order.EntryDate >= cutoffDate)
                    .ToList();
                result.Success = true;
                result.Message = "Orders retrieved successfully.";
            }
            catch (Exception ex)
            {
                result.Success = false;
                result.Message = $"An error occurred: {ex.Message}";
            }
            return result;
        }

        private static bool IsHoliday(DateTime date)
        {
            var holidays = new HashSet<DateTime>
        {
            new DateTime(DateTime.Now.Year, 1, 1),
            new DateTime(DateTime.Now.Year, 2, 19),
            new DateTime(DateTime.Now.Year, 6, 19),
            new DateTime(DateTime.Now.Year, 7, 4),
            new DateTime(DateTime.Now.Year, 12, 25),
        };
            return holidays.Contains(date.Date);
        }

        private static bool IsWeekday(DateTime date)
        {
            return date.DayOfWeek != DayOfWeek.Saturday && date.DayOfWeek != DayOfWeek.Sunday;
        }
    }
}
