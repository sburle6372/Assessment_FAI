﻿using FluentAssertions;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Moq;
using SampleAPI.Controllers;
using SampleAPI.Entities;
using SampleAPI.Repositories;
using SampleAPI.Requests;
using SampleAPI.Responses;

namespace SampleAPI.Tests.Controllers
{
    public class OrdersControllerTests
    {
        private readonly OrdersController _controller;
        private readonly Mock<IOrderRepository> _mockRepository;

        public OrdersControllerTests()
        {
            _mockRepository = new Mock<IOrderRepository>();
            _controller = new OrdersController(_mockRepository.Object);
        }

        [Fact]
        public void GetRecentOrders_ReturnsOkResult_WithOrders()
        {
            // Arrange
            var orders = new List<Order>
        {
            new Order { Id = 1, EntryDate = DateTime.Now.AddDays(-1), CustomerName = "John Doe", OrderDescription = "three items added to cart", IsDeleted = false, IsInvoiced = true },
            new Order { Id = 2, EntryDate = DateTime.Now, CustomerName = "Jane Doe", OrderDescription = "four items added to cart", IsDeleted = true, IsInvoiced = true }
        };
            _mockRepository.Setup(repo => repo.GetRecentOrder()).Returns(new OrdersResult
            {
                Success = true,
                Orders = orders
            });

            // Act
            var result = _controller.GetRecentOrders();

            // Assert
            Assert.NotNull(result);
            Assert.Equal(orders, result.Value);
        }

        [Fact]
        public void AddNewOrder_ReturnsCreatedAtActionResult_WithOrder()
        {
            // Arrange
            var order = new Order { Id = 3, EntryDate = DateTime.Now, CustomerName = "Alice Smith", OrderDescription = "five items added to cart", IsDeleted = false, IsInvoiced = true };
            _mockRepository.Setup(repo => repo.AddNewOrder(order)).Returns(new ResponseResult
            {
                Success = true,
                Message = "Order added successfully."
            });

            // Act
            var result = _controller.AddNewOrder(order);

            // Assert
            Assert.NotNull(result);
            Assert.Equal(order, result.Value);
        }

        [Fact]
        public void GetOrdersExcludingHolidaysAndWeekends_ReturnsOkResult_WithOrders()
        {
            var orders = new List<Order>
        {
            new Order { Id = 1, EntryDate = DateTime.Now.AddDays(-1), CustomerName = "John Doe", OrderDescription = "three items added to cart", IsDeleted = false, IsInvoiced = true },
            new Order { Id = 2, EntryDate = DateTime.Now, CustomerName = "Jane Doe", OrderDescription = "four items added to cart", IsDeleted = true, IsInvoiced = true }
        };
            _mockRepository.Setup(repo => repo.GetRecentOrder()).Returns(new OrdersResult
            {
                Success = true,
                Orders = orders
            });

            // Act
            var result = _controller.GetOrdersExcludingHolidaysAndWeekends(5);

            // Assert
            Assert.NotNull(result);
            Assert.Equal(orders, result.Value);
        }
    }
}
